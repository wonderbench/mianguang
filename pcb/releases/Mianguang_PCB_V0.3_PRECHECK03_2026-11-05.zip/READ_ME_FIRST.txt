眠光PCB V0.3 PRECHECK03，2026-11-05

最新工程、完整BOM、原生坐标和Gerber：pcb/release_v03_precheck03/
重新上传PCB DFM：pcb/preflight_v03/Mianguang_V0.3_DFM_PRECHECK_03.zip
SMT专用BOM和坐标：pcb/preflight_v03/smt_precheck03/
原理图与PCB原生检查均零提示；本地验收49/49、制造几何40/40通过。
03在线复检和SMT尚未完成，未制造放行。8条插件到SMT间距提示需按后续手工焊接条件由贴片方确认。D2实物色带及贴装方向仍需确认。

归档保留V0.2和PRECHECK02源及其检查证据，方便复核；这些不是当前上传文件。
用户02在线报告在pcb/qa/v03/online_dfm/；03差异、极性和导出证据在pcb/qa/v03/precheck03/。
当前仓库索引以GitHub仓库pcb/LATEST.json为准，本包不包含该可变索引。
